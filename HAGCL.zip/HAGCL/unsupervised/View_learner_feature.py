import torch
import copy
from torch.nn import Sequential, Linear, ReLU
# 调用gumbel_softmax函数。
import torch.nn.functional as F


class ViewLearner_feature(torch.nn.Module):
    def __init__(self, encoder, mlp_edge_model_dim=64):
        super(ViewLearner_feature, self).__init__()

        self.encoder = encoder
        self.input_dim = self.encoder.out_node_dim

        self.mlp_edge_model = Sequential(
            Linear(self.input_dim, mlp_edge_model_dim),
            ReLU(),
            Linear(mlp_edge_model_dim, 2)
        )
        self.init_emb()

    def init_emb(self):
        for m in self.modules():
            if isinstance(m, Linear):
                torch.nn.init.xavier_uniform_(m.weight.data)
                if m.bias is not None:
                    m.bias.data.fill_(0.0)

    def forward(self, batch, x, edge_index, edge_attr):#x=batch.x

        data = copy.deepcopy(x)

        _, node_emb = self.encoder(batch, data, edge_index, edge_attr)  # 原始数据经过GNN得到嵌入表示为node_emb

        feature_logits = self.mlp_edge_model(node_emb)  # 每个节点得到两个值

        #权重经过gumbel-softmax采样来获得概率，
        sample = F.gumbel_softmax(feature_logits, hard=True)   #权重经过gumbel-softmax采样来获得概率，hard为true的情况下，得到的是0或者1的值.1为mask。
        mask_idx =sample[:,1] #sample是一个二维矩阵，我们取的值要华为一个整张量。
         # mask_idx = torch.nonzero(feature_weight, as_tuple=False).view(-1, ) #统计mask点。1为mask，0为保留。

        attr_mask_idx = mask_idx.bool()
        token = x.detach().mean()
        x1=token.shape
        x2=data.shape
        data[attr_mask_idx] = token  #mask

        #为什么不能用0掩蔽？因为infomin时，会直接让节点信息全为0，这样就得到一个0的嵌入，做损失的时候log（0）明显出错误。
        #那为什么edge可以呢？
        #很简单，因为edge再删除最后也不会导致嵌入表示为0，

        x = data


        return x
