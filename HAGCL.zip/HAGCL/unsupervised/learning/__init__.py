from .ginfomax import InfoGraph
from .ginfominmax import GInfoMinMax
from .gsimclr import GSimCLR
