import argparse
import logging
import random
#python main.py --dataset MUTAG

#logging.getLogger().setLevel(logging.INFO)
import numpy as np
import torch
from sklearn.svm import LinearSVC, SVC
from torch_geometric.loader import DataLoader

from torch_geometric.transforms import Compose
from torch_scatter import scatter

from datasets import TUDataset, TUEvaluator
from unsupervised.embedding_evaluation import EmbeddingEvaluation
from unsupervised.encoder import TUEncoder
from unsupervised.learning import GInfoMinMax
from unsupervised.utils import initialize_edge_weight, initialize_node_features, set_tu_dataset_y_shape
from unsupervised.view_learner import ViewLearner
from unsupervised.View_learner_feature import ViewLearner_feature


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    np.random.seed(seed)
    random.seed(seed)




def run(args):
    # logging.getLogger().setLevel(logging.INFO)
    root_logger = logging.getLogger()
    for h in root_logger.handlers:
        root_logger.removeHandler(h)
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logging.info("Using Device: %s" % device)
    logging.info("Seed: %d" % args.seed)
    logging.info(args)
    setup_seed(args.seed)

    evaluator = TUEvaluator()
    my_transforms = Compose([initialize_node_features, initialize_edge_weight, set_tu_dataset_y_shape])
    dataset = TUDataset("./original_datasets/", args.dataset, transform=my_transforms)
    if dataset.data.x is not None:
        featuresize=dataset.data.x.shape[1]
    else:
        featuresize = 1


    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True)


    model = GInfoMinMax(
        TUEncoder(num_dataset_features=featuresize, emb_dim=args.emb_dim, num_gc_layers=args.num_gc_layers, drop_ratio=args.drop_ratio, pooling_type=args.pooling_type),
        args.emb_dim).to(device)

    model_optimizer = torch.optim.Adam(model.parameters(), lr=args.model_lr)


    view_learner = ViewLearner(TUEncoder(num_dataset_features=featuresize, emb_dim=args.emb_dim, num_gc_layers=args.num_gc_layers, drop_ratio=args.drop_ratio, pooling_type=args.pooling_type),
                               mlp_edge_model_dim=args.mlp_edge_model_dim).to(device)
    view_optimizer = torch.optim.Adam(view_learner.parameters(), lr=args.view_lr)

    ###
    view_learner_feature = ViewLearner_feature(TUEncoder(num_dataset_features=featuresize, emb_dim=args.emb_dim, num_gc_layers=args.num_gc_layers,
                                         drop_ratio=args.drop_ratio, pooling_type=args.pooling_type),
                               mlp_edge_model_dim=args.mlp_edge_model_dim).to(device)
    view_optimizer_feature = torch.optim.Adam(view_learner_feature.parameters(), lr=args.view_lr)
    ###

    if args.downstream_classifier == "linear":
        ee = EmbeddingEvaluation(LinearSVC(dual=False, fit_intercept=True,max_iter=100000), evaluator, dataset.task_type, dataset.num_tasks,
                             device, param_search=True)
    else:
        ee = EmbeddingEvaluation(SVC(), evaluator, dataset.task_type,
                                 dataset.num_tasks,
                                 device, param_search=True)

    model.eval()
    train_score, val_score, test_score = ee.kf_embedding_evaluation(model.encoder, dataset)
    logging.info(
        "Before training Embedding Eval Scores: Train: {} Val: {} Test: {}".format(train_score, val_score,
                                                                                         test_score))


    model_losses = []
    # view_losses = []
    view_mask_losses = []
    view_edge_losses = []
    view_regs = []
    valid_curve = []
    test_curve = []
    train_curve = []

    for epoch in range(1, args.epochs + 1):
        model_loss_all = 0

        view_loss_edge_all = 0
        view_loss_mask_all = 0

        reg_all = 0
        for batch in dataloader:
            # set up
            batch = batch.to(device)


            # train view to maximize contrastive loss
            view_learner.train()
            view_learner.zero_grad()
            view_learner_feature.train()
            view_learner_feature.zero_grad()

             #一开始model只作为表示而不更新，所以用全部参数来进行表示。。。
            model.eval()
            # model.train()


            x, _ = model(batch.batch, batch.x, batch.edge_index, None, None)

            edge_logits = view_learner(batch.batch, batch.x, batch.edge_index, None)

            x_mask = view_learner_feature(batch.batch, batch.x, batch.edge_index, None)

            temperature = 1.0
            bias = 0.0 + 0.0001  # If bias is 0, we run into problems
            eps = (bias - (1 - bias)) * torch.rand(edge_logits.size()) + (1 - bias)
            gate_inputs = torch.log(eps) - torch.log(1 - eps)
            gate_inputs = gate_inputs.to(device)
            gate_inputs = (gate_inputs + edge_logits) / temperature
            batch_aug_edge_weight = torch.sigmoid(gate_inputs).squeeze()

            x_edge_aug, _ = model(batch.batch, batch.x, batch.edge_index, None, batch_aug_edge_weight)
            x_mask_aug, _ = model(batch.batch, x_mask, batch.edge_index, None, None)

            view_loss_edge = model.calc_loss(x, x_edge_aug,sym=False)
            view_loss_mask = model.calc_loss(x, x_mask_aug,sym=False)


            view_loss_edge_all += view_loss_edge.item() * batch.num_graphs

            view_loss_mask_all += view_loss_mask.item() * batch.num_graphs

            # gradient ascent formulation

            ###
            ###踩坑提醒，多个loss计算时会报错，因为系统buffer中只会保存一次梯度，之后就会清零，两个不同loss会导致第一个loss报错，所以用retain_graph=True
            (-view_loss_edge).backward(retain_graph=True)
            view_optimizer.step()

            (-view_loss_mask).backward()
            view_optimizer_feature.step()
            # (-view_loss_mask).backward()
            # view_optimizer.step()


            # train (model) to minimize contrastive loss
            model.train()
            # view_learner.eval()  #经过原始的训练后用全部参数进行表示，不用drop_out
            model.zero_grad()
            view_learner.zero_grad()
            view_learner_feature.zero_grad()


            x,  _ = model(batch.batch, batch.x, batch.edge_index, None, None)

            edge_logits = view_learner(batch.batch, batch.x, batch.edge_index, None)

            x_mask = view_learner_feature(batch.batch, batch.x, batch.edge_index, None)

            temperature = 1.0
            bias = 0.0 + 0.0001  # If bias is 0, we run into problems
            eps = (bias - (1 - bias)) * torch.rand(edge_logits.size()) + (1 - bias)
            gate_inputs = torch.log(eps) - torch.log(1 - eps)
            gate_inputs = gate_inputs.to(device)
            gate_inputs = (gate_inputs + edge_logits) / temperature
            # batch_aug_edge_weight = torch.sigmoid(gate_inputs).squeeze().detach()
            batch_aug_edge_weight = torch.sigmoid(gate_inputs).squeeze()

            x_edge_aug, _ = model(batch.batch, batch.x, batch.edge_index, None, batch_aug_edge_weight)

            x_mask_aug, _ = model(batch.batch, x_mask, batch.edge_index, None, None)


            #采样训练
            # input_list = [x, x_edge_aug, x_mask_aug]
            # input1, input2 = random.sample(input_list, k=2)
            # model_loss = model.calc_loss(input1, input2)

            #对应的采样
            ############################################
            input_list = [x, x_edge_aug, x_mask_aug]
            input1, input2 = random.sample(input_list, k=2)
            if input1.equal(x) and input2.equal(x_edge_aug):
                model_loss = model.calc_loss(input1, input2,sym=False)
                model_loss.backward()
                model_optimizer.step()
                view_optimizer.step()
            if input2.equal(x) and input1.equal(x_edge_aug):
                model_loss = model.calc_loss(input2, input1, sym=False)
                model_loss.backward()
                model_optimizer.step()
                view_optimizer.step()
            if input1.equal(x) and input2.equal(x_mask_aug):
                model_loss = model.calc_loss(input1, input2, sym=False)
                model_loss.backward()
                model_optimizer.step()
                view_optimizer_feature.step()
            if input2.equal(x) and input1.equal(x_mask_aug):
                model_loss = model.calc_loss(input2, input1, sym=False)
                model_loss.backward()
                model_optimizer.step()
                view_optimizer_feature.step()
            if input1.equal(x_mask_aug) and input2.equal(x_edge_aug):
                model_loss = model.calc_loss(input1, input2)
                model_loss.backward()
                model_optimizer.step()
                view_optimizer.step()
                view_optimizer_feature.step()
            if input2.equal(x_mask_aug) and input1.equal(x_edge_aug):
                model_loss = model.calc_loss(input1, input2)
                model_loss.backward()
                model_optimizer.step()
                view_optimizer.step()
                view_optimizer_feature.step()
            ###############################################


            # model_loss = model.calc_loss(x_mask_aug, x_edge_aug)



            model_loss_all += model_loss.item() * batch.num_graphs
            # standard gradient descent formulation
            # model_loss.backward()
            # model_optimizer.step()
            # # #infomax进行更新
            # view_optimizer.step()
            # view_optimizer_feature.step()

        fin_model_loss = model_loss_all / len(dataloader)
        fin_view_mask_loss = view_loss_mask_all / len(dataloader)
        fin_view_edge_loss = view_loss_edge_all / len(dataloader)
        fin_reg = reg_all / len(dataloader)

        logging.info('Epoch {}, Model Loss {}, View mask Loss {}, View edge Loss {}'.format(epoch, fin_model_loss, fin_view_mask_loss,fin_view_edge_loss))
        model_losses.append(fin_model_loss)
        view_mask_losses.append(fin_view_mask_loss)
        view_edge_losses.append(fin_view_edge_loss)

        if epoch % args.eval_interval == 0: #每5个epoch进行一次分类
            model.eval()

            train_score, val_score, test_score = ee.kf_embedding_evaluation(model.encoder, dataset)

            logging.info(
                "Metric: {} Train: {} Val: {} Test: {}".format(evaluator.eval_metric, train_score, val_score, test_score))

            train_curve.append(train_score)
            valid_curve.append(val_score)
            test_curve.append(test_score)

    if 'classification' in dataset.task_type:
        best_val_epoch = np.argmax(np.array(valid_curve))
        best_train = max(train_curve)
    else:
        best_val_epoch = np.argmin(np.array(valid_curve))
        best_train = min(train_curve)

    logging.info('FinishedTraining!')
    logging.info('BestEpoch: {}'.format(best_val_epoch))
    logging.info('BestTrainScore: {}'.format(best_train))
    logging.info('BestValidationScore: {}'.format(valid_curve[best_val_epoch]))
    logging.info('FinalTestScore: {}'.format(test_curve[best_val_epoch]))


    return valid_curve[best_val_epoch], test_curve[best_val_epoch]


def arg_parse():
    parser = argparse.ArgumentParser(description='AD-GCL TU')

    parser.add_argument('--dataset', type=str, default='MUTAG',
                        help='Dataset')
    parser.add_argument('--model_lr', type=float, default=0.001,
                        help='Model Learning rate.')
    parser.add_argument('--view_lr', type=float, default=0.001,
                        help='View Learning rate.')
    parser.add_argument('--num_gc_layers', type=int, default=5,

                        help='Number of GNN layers before pooling')
    parser.add_argument('--pooling_type', type=str, default='standard',
                        help='GNN Pooling Type Standard/Layerwise')
    parser.add_argument('--emb_dim', type=int, default=32,
                        help='embedding dimension')
    parser.add_argument('--mlp_edge_model_dim', type=int, default=64,
                        help='embedding dimension')
    parser.add_argument('--batch_size', type=int, default=32,
                        help='batch size')
    parser.add_argument('--drop_ratio', type=float, default=0.5,
                        help='Dropout Ratio / Probability')
    parser.add_argument('--epochs', type=int, default=150,
                        help='Train Epochs')
    parser.add_argument('--reg_lambda', type=float, default=0, help='View Learner Edge Perturb Regularization Strength')
    parser.add_argument('--eval_interval', type=int, default=3, help="eval epochs interval")

    parser.add_argument('--downstream_classifier', type=str, default="linear", help="Downstream classifier is linear or non-linear")
    

    parser.add_argument('--seed', type=int, default=0
                        )

    return parser.parse_args()


if __name__ == '__main__':

    args = arg_parse()
    run(args)