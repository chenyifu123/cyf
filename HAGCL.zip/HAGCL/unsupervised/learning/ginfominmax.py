import torch
from torch.nn import Sequential, Linear, ReLU


class GInfoMinMax(torch.nn.Module):
	def __init__(self, encoder, proj_hidden_dim=300):
		super(GInfoMinMax, self).__init__()

		self.encoder = encoder
		self.input_proj_dim = self.encoder.out_graph_dim

		self.proj_head = Sequential(Linear(self.input_proj_dim, proj_hidden_dim), ReLU(inplace=True),
									   Linear(proj_hidden_dim, proj_hidden_dim))

		self.init_emb()

	def init_emb(self):
		for m in self.modules():
			if isinstance(m, Linear):
				torch.nn.init.xavier_uniform_(m.weight.data)
				if m.bias is not None:
					m.bias.data.fill_(0.0)

	def forward(self, batch, x, edge_index, edge_attr, edge_weight=None):

		z, node_emb = self.encoder(batch, x, edge_index, edge_attr, edge_weight)

		z = self.proj_head(z)
		# z shape -> Batch x proj_hidden_dim
		return z, node_emb

	@staticmethod
	def calc_loss( x, x_aug, temperature=0.2,sym=True):
		# x and x_aug shape -> Batch x proj_hidden_dim
		# batch_size, _ = x1.size()
		# x1_abs = x1.norm(dim=1)
		# x2_abs = x2.norm(dim=1)
		#
		# sim_matrix_a = torch.einsum('ik,jk->ij', x1, x2) / torch.einsum('i,j->ij', x1_abs, x2_abs)
		# sim_matrix_a = torch.exp(sim_matrix_a / temperature)
		# pos_sim_a = sim_matrix_a[range(batch_size), range(batch_size)]
		#
		# loss_a = pos_sim_a / (sim_matrix_a.sum(dim=1) - pos_sim_a)
		# loss_a = - torch.log(loss_a).mean()
		#
		# sim_matrix_b = torch.einsum('ik,jk->ij', x2, x1) / torch.einsum('i,j->ij', x2_abs, x1_abs)
		# sim_matrix_b = torch.exp(sim_matrix_b / temperature)
		# pos_sim_b = sim_matrix_b[range(batch_size), range(batch_size)]
		# loss_b = pos_sim_b / (sim_matrix_b.sum(dim=1) - pos_sim_b)
		# loss_b = - torch.log(loss_b).mean()
		#
		# loss = (loss_a + loss_b) / 2
		# return loss

		batch_size, _ = x.size()
		x_abs = x.norm(dim=1)
		x_aug_abs = x_aug.norm(dim=1)

		sim_matrix = torch.einsum('ik,jk->ij', x, x_aug) / torch.einsum('i,j->ij', x_abs, x_aug_abs)
		sim_matrix = torch.exp(sim_matrix / temperature)
		pos_sim = sim_matrix[range(batch_size), range(batch_size)]
		if sym:

			loss_0 = pos_sim / (sim_matrix.sum(dim=0) - pos_sim)
			loss_1 = pos_sim / (sim_matrix.sum(dim=1) - pos_sim)

			loss_0 = - torch.log(loss_0).mean()
			loss_1 = - torch.log(loss_1).mean()
			loss = (loss_0 + loss_1) / 2.0
		else:
			loss = pos_sim / (sim_matrix.sum(dim=1) - pos_sim)
			loss = - torch.log(loss).mean()

		return loss


		return loss


